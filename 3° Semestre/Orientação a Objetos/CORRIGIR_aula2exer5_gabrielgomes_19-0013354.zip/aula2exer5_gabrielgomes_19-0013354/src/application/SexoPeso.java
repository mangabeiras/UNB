package application;

import java.util.Locale;
import java.util.Scanner;

public class SexoPeso {

	public static void main(String[] args) {

		Locale.setDefault(Locale.US);

		// DECLARACOES
		Scanner sc = new Scanner(System.in);
		final int QTDPESSOAS = 20;
		String sexo;
		float peso;
		float pesoMax = 0f;
		float pesoMin = 1000f;
		float somaPesoMasc = 0f;
		int qtdFem = 0;

		// INSTRUCOES
		for (int i = 0; i < QTDPESSOAS; i++) {

			System.out.print("Digite o peso e o sexo (masculino/feminino) da " + (i + 1) + " pessoa: ");
			peso = sc.nextFloat();
			sexo = sc.next();

			while (sexo.intern() != "masculino" && sexo.intern() != "feminino") {

				System.out.print("Sexo invalido! Digite novamente (masculino/feminino): ");
				sexo = sc.next();

			}
			
			// PESO MAX E MIN
			if (peso > pesoMax) {

				pesoMax = peso;

			} else if (peso < pesoMin) {

				pesoMin = peso;

			}
			
			if(sexo.intern() == "masculino") {
				
				somaPesoMasc += peso;
				
			} else {
				
				qtdFem++;
				
			}
			
		}
		
		// IMPRESSAO
		System.out.println("O maior e o menor peso informados foram: " + pesoMax + " KG, " + pesoMin + " KG");
		System.out.println("A media dos pesos dos homens e: " + somaPesoMasc / (QTDPESSOAS - qtdFem));
		System.out.println("A quantidade de mulheres e: " + qtdFem);
		
		sc.close();

	}


}
