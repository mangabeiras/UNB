import java.util.Scanner;
public class Senha {   
    
    public static void main(String[] args) {
        
        String senha, tentativa;
        final int MAXIMO = 9;
        Scanner scan = new Scanner(System.in);
    
        System.out.println("Digite uma senha");         //l� a senha
        senha = scan.nextLine();
        
        while(verificaSenha(senha)){
            pulaLinha(20);
            System.out.println("Senha inv�lida");
            System.out.println("Insira outra senha");
            senha = scan.nextLine();
        }
        
        int a = 0;
        pulaLinha(20);
        
    for (a = 0; a < MAXIMO; a++){                       //compara as senhas
        System.out.println("Digite uma senha");
        tentativa = scan.nextLine();
        if (tentativa.equals(senha)){
        pulaLinha(21);
        System.out.print("\t\t\tParab�ns");
        break;
    }
    System.out.println("Senha incorreta");
}
scan.close();

if (a == MAXIMO){
    System.out.println("O computador ir� se autodestruir em 10 segundos");
    try {
        Thread.sleep(10000);
    } catch (InterruptedException ie) {
        Thread.currentThread().interrupt();
    }
}

}
    public static void pulaLinha(int numeroLinhas){
            System.out.println();
        for(int i = 0; i<numeroLinhas; i++)
            System.out.println();
    }
    
    public static boolean verificaSenha(String senha){
        if (senha.length() < 3 || senha.length() > 5)
            return true;
    for (int a = 0 ; a < senha.length(); a++){
        if (senha.charAt(a) == ' ')
            return true;
    }
        return false;
    }
}