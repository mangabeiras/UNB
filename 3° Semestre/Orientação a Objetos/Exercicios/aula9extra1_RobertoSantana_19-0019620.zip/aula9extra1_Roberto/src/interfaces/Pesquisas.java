package interfaces;

public interface Pesquisas {
	void mostraContaminados(int comparador);
	boolean hasMaior(int comparador);
}
