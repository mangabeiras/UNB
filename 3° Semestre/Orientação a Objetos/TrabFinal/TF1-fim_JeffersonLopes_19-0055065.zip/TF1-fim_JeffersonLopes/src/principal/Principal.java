package principal;

import saida.Tela_Principal;

public class Principal {

	public static void main(String[] args) {
		new Tela_Principal().setVisible(true);
	}
}