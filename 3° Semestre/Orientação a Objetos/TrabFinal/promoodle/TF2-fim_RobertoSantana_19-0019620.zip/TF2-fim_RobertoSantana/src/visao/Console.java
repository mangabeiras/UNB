package visao;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import dados.Grupo;
import dados.Pessoa;

public class Console {
	// LIMPA A TELA DA CONSOLE
	private static void limpaTela(int saltos) {
		for (int contador = 0; contador < saltos; contador++)
			System.out.println();
	}


	// RESULTADO
	public static void mostraResultado(Grupo grupo) {
		DecimalFormat mascara = new DecimalFormat("00");

		limpaTela(50);
		System.out.println("                    "+mascara.format(calculaCasos(grupo, 'C')) + " = CONTAMINADOS CURADOS");
		System.out.println("                    "+mascara.format(calculaCasos(grupo, 'T')) + " = CONTAMINADOS EM TRATAMENTO");
		System.out.println("                    "+mascara.format(calculaCasos(grupo, 'F')) + " = CONTAMINADOS FALECIDOS");
		System.out.println("                    "+mascara.format(pessoasSemContaminacao(grupo, 'h')) + " = HOMENS SEM CONTAMINACAO");
		System.out.println("                    "+mascara.format(pessoasSemContaminacao(grupo, 'm')) + " = MULHERES SEM CONTAMINACAO");
		System.err.println("                    "+mascara.format(grupo.getGrupo().size()) + " = TOTAL DE REGISTRO DE PESSOAS");
	}

	// QUANTIDADE DE MULHERES OU HOMENS SEM CONTAMINACAO
	private static int pessoasSemContaminacao(Grupo grupo, char a) {
		int casos = 0;
		for (Pessoa pessoa : grupo.getGrupo()) {
			if (pessoa.toString().split(" ")[1].equals("--") && a == 'm' && pessoa.getSituacao() == 'S')
				casos++;
			if (pessoa.toString().split(" ")[0].equals("--") && a == 'h' && pessoa.getSituacao() == 'S')
				casos++;
		}
		return casos;
	}

	// QUANTIDADE DE CASOS POR TIPO
	private static int calculaCasos(Grupo grupo, char a) {
		int casos = 0;
		for (Pessoa pessoa : grupo.getGrupo()) {
			if (pessoa.getSituacao() == a)
				casos++;
		}
		return casos;
	}
}
